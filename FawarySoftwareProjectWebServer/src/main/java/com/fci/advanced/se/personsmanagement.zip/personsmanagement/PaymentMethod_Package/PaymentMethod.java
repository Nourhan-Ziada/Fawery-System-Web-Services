package com.fci.advanced.se.personsmanagement.PaymentMethod_Package;

public enum PaymentMethod {
    CreditCard , Wallet , CacheOnDelivery
}
