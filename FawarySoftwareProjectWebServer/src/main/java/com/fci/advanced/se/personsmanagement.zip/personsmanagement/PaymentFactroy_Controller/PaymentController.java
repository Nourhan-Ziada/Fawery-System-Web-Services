package com.fci.advanced.se.personsmanagement.PaymentFactroy_Controller;
import com.fci.advanced.se.personsmanagement.Common.Common;
import com.fci.advanced.se.personsmanagement.PaymentMethod_Package.Payment;
import com.fci.advanced.se.personsmanagement.PaymentMethod_Package.WalletPayment;
import com.fci.advanced.se.personsmanagement.Service_Package.Service;
import com.fci.advanced.se.personsmanagement.Service_Package.ServiceController;
import com.fci.advanced.se.personsmanagement.model.CurrentUser;
import com.fci.advanced.se.personsmanagement.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/Payment")
public class PaymentController {

    public static void callPay(User user , float totalCost, Service service , Payment paymentMethod)
    {

        if (paymentMethod.pay(user , totalCost) != -1 )
        {

//            Transaction transaction = new Transaction(service,totalCost);
//
//            if(user.getUserHistory() ==null)
//            {
//                UserHistory userHistory = new UserHistory();
//                userHistory.addTransaction(transaction);
//                user.setUserHistory(userHistory);
//            }
//            user.getUserHistory().addTransaction(transaction);
//
//            PaymentSelection.confirmPayment(transaction.getTransactionId(), totalCost);
//        }
    }
}


    @GetMapping("/Payment")
    public  float payByWallet(List<String> paymentData)
    { // I sent user as I need it to pay but when I separate senior I should remove it from req service and call service
        PaymentFactory paymentCreator = new PaymentCreator();
        Payment payment = paymentCreator.createPaymentMethod(paymentData);
        User activeUser = CurrentUser.user;
        return walletPayment.pay(activeUser, ServiceController.totalCost);
    }
}
