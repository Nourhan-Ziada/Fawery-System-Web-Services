package com.fci.advanced.se.personsmanagement.Discount;


import com.fci.advanced.se.personsmanagement.Service_Package.*;
import com.fci.advanced.se.personsmanagement.model.Response;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/SpecificDiscountController")
public class SpecificDiscountController {

    private ServiceFactory serviceFactory;

    public void setServiceFactory(ServiceFactory serviceFactory) {
        this.serviceFactory = serviceFactory;
    }

    public SpecificDiscountController(){}
    @GetMapping("add/{serviceName}/{discountValue}")
    public  Response addSpecificDiscount(@PathVariable("serviceName") ServiceType serviceName,@PathVariable("discountValue") float discountValue) {
        Response response = new Response();
             AllService allService = new AllService();
            allService.setupService();
            Service service = ServiceEntity.searchForService(serviceName);
            SpecificDiscountDecorator specificDiscountDecorator = new SpecificDiscountDecorator(service, discountValue);
            ServiceEntity.removeService(service);
            specificDiscountDecorator.setServiceName(serviceName);
            ServiceEntity.addService(specificDiscountDecorator);
            response.setStatus(true);
            response.setMessage("Discount added successfully");
            response.object = specificDiscountDecorator;
            return response;
        }
}

