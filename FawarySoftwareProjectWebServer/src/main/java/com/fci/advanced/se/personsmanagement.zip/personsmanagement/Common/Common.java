package com.fci.advanced.se.personsmanagement.Common;

import com.fci.advanced.se.personsmanagement.model.User;

import java.util.HashMap;
import java.util.Map;

public class Common {
    public static Map<String, User> userMap = new HashMap<String, User>();
    public static User user ;

}
