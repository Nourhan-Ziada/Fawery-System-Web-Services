package com.fci.advanced.se.personsmanagement.ProviderEntity.LandLine;

public class LandLineQuarter extends TelecomEgyptProvider {
    @Override
    public float retrieveAmount() {
        return 300;
    }
}
