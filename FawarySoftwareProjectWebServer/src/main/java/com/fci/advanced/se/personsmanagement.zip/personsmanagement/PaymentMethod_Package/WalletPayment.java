package com.fci.advanced.se.personsmanagement.PaymentMethod_Package;

import com.fci.advanced.se.personsmanagement.model.CurrentUser;
import com.fci.advanced.se.personsmanagement.model.User;

public class WalletPayment implements Payment{
    @Override
    public float pay(User user, float totalCost) {
        if(user.getWallet().getBalance() >= totalCost)
        {
            user.getWallet().consumeMoney(totalCost);
            return (user.getWallet().getBalance());
        }
       return -1;
    }
}
