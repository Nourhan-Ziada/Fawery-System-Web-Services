package com.fci.advanced.se.personsmanagement.PaymentMethod_Package;

import com.fci.advanced.se.personsmanagement.model.CurrentUser;
import com.fci.advanced.se.personsmanagement.model.User;

public interface Payment {
    float pay(User user , float totalCost); // force

}
