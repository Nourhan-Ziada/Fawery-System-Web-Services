package com.fci.advanced.se.personsmanagement.ProviderEntity.LandLine;

public class landLineMonthly extends TelecomEgyptProvider {
    @Override
    public float retrieveAmount() {
        return 100;
    }
}
