package com.fci.advanced.se.personsmanagement.ProviderEntity;

public interface IProvider {
  float retrieveAmount();
}
