package com.fci.advanced.se.personsmanagement.model;

import com.fci.advanced.se.personsmanagement.RefundOperation.Transaction;
import com.fci.advanced.se.personsmanagement.Service_Package.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class UserHistory {
    private Map<Integer, Transaction> userMap = new HashMap<Integer, Transaction>();
    public  int searchForNumberTransactionService( Service service){
        int counter= 0;
        for (Map.Entry<Integer,Transaction> entry : userMap.entrySet())
        {
            if(entry.getValue().getService()==service)
            {
                counter++;
            }
        }
        return counter ;
    }
    public void addTransaction(Transaction transaction){

        userMap.put(transaction.getTransactionId(),transaction);


    }
    public void removeTransaction(Transaction transaction){

        userMap.remove(transaction.getTransactionId(),transaction);


    }

    public Transaction searchForTransaction(int transactionId)
    {
        for (Map.Entry<Integer,Transaction> entry : userMap.entrySet()) {

            if (userMap.isEmpty())
                return null;

            else if (Objects.equals(entry.getValue().getTransactionId(), transactionId)) {
                return entry.getValue();
            }
        }
        return null;
    }

//    public  int searchForNumberTransactionService( Service service){
//        int counter= 0;
//        for (Map.Entry<Integer,Transaction> entry : userMap.entrySet())
//        {
//            if(entry.getValue().getService()==service)
//            {
//                counter++;
//            }
//        }
//        return counter ;
//    }



}
