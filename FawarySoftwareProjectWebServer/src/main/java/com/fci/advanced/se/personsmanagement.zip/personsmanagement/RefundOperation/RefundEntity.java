package com.fci.advanced.se.personsmanagement.RefundOperation;

import com.fci.advanced.se.personsmanagement.model.User;

import java.util.HashMap;
import java.util.Map;

public  class RefundEntity {

    private static RefundEntity refundEntity  ;
    private static Map<User, Transaction> mapRequestRefund = new HashMap<User, Transaction>();
    private Map<User, Transaction>  mapaccapetRefund = new HashMap<User, Transaction>();

    private RefundEntity(Map<User, Transaction>mapRequestRefund) {
        this.mapRequestRefund = mapRequestRefund ;
    }

    public static Map<User, Transaction> getMapRequestRefund() {
        return mapRequestRefund;
    }

    public static void setMapRequestRefund(Map<User, Transaction> mapRequestRefund) {
        RefundEntity.mapRequestRefund = mapRequestRefund;
    }

    public static void addRefund(User user, Transaction transaction){

        mapRequestRefund.put(user,transaction);


    }
    public static void removeRefund(User user, Transaction transaction){

        mapRequestRefund.remove(user,transaction);


    }
    public static RefundEntity getInstance(Map<User, Transaction> mapRequestRefund)
    {
        if(refundEntity == null) {
            refundEntity = new RefundEntity(mapRequestRefund);
        }

        return refundEntity ;
    }




}
