package com.fci.advanced.se.personsmanagement.Discount;


import com.fci.advanced.se.personsmanagement.Service_Package.Service;
import com.fci.advanced.se.personsmanagement.Service_Package.ServiceEntity;
import com.fci.advanced.se.personsmanagement.Service_Package.ServiceFactory;
import com.fci.advanced.se.personsmanagement.Service_Package.ServiceType;

import java.util.Map;

public class OverallDiscountController {
    private OverallDiscountDecorator overallDiscountObj;
    private ServiceFactory serviceFactory;

    public void setServiceFactory(ServiceFactory serviceFactory) {
        this.serviceFactory = serviceFactory;
    }

    public OverallDiscountDecorator getOverallDiscountObj() {
        return overallDiscountObj;
    }
    public  void setOverallDiscountObj(OverallDiscountDecorator overallDiscountObj) {
        overallDiscountObj = overallDiscountObj;
    }
    public  void addOverallDiscount( float discountValue, int transactionNumber) {
        for ( Map.Entry<ServiceType, Service> entry : ServiceEntity.getServiceMap().entrySet()) {
            System.out.println(entry.getKey() + " " + entry.getValue().getServiceName());
        }
        for ( Map.Entry<ServiceType, Service> entry : ServiceEntity.getServiceMap().entrySet()) {
            {
               OverallDiscountDecorator overallDiscountDecorator = new OverallDiscountDecorator(entry.getValue(), discountValue, transactionNumber);
                overallDiscountDecorator.setServiceName(entry.getKey());
                ServiceEntity.addService(overallDiscountDecorator);
            }
        }
    }
//    public Service checkOverallDiscountForUser(User user, Service service) {
//        if (user.getUserHistory() != null) {
//            int num = user.getUserHistory().searchForNumberTransactionService(service);
//
//        }
//
//    }
}



