package com.fci.advanced.se.personsmanagement.model;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class CurrentUser {
    public static User user;
}
