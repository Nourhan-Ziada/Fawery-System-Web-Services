package com.fci.advanced.se.personsmanagement.Service_Package;

public interface ServiceFactory {
      Service CreateService(ServiceType serviceType);
}
