package com.fci.advanced.se.personsmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
@Getter
@Setter
@AllArgsConstructor
public class User {
    private String name ;
    @Autowired
    private Account account ;
    @Autowired
    private  Wallet wallet ;
    private  UserHistory userHistory ;
}
