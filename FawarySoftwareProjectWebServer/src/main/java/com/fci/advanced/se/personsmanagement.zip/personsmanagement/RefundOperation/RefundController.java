package com.fci.advanced.se.personsmanagement.RefundOperation;

import com.fci.advanced.se.personsmanagement.Service_Package.ServiceType;
import com.fci.advanced.se.personsmanagement.model.User;

import java.util.HashMap;
import java.util.Map;

public class RefundController {

  private static String text  ;

    public String  RefundRequest(User user, int transactionId , ServiceType serviceType) {

        if (user.getUserHistory() == null) {
            text = "there is no history";
            return text;

        } else {
            Transaction transaction = user.getUserHistory().searchForTransaction(transactionId);


            if (RefundEntity.getMapRequestRefund() == null) {
                Map<User, Transaction> mapRequestRefund = new HashMap<>();
                mapRequestRefund.put(user, transaction);
                RefundEntity refundEntity = RefundEntity.getInstance(mapRequestRefund);

            }
            if (transaction != null) {
                RefundEntity.addRefund(user, transaction);
                 text ="Request is under processing" ;
                 return text;


            } else {
                text = "Sorry Request Not Found";
               return text ;

            }

        }
    }
   public static void replyRequestReFund(Boolean reply , Transaction transaction ,User user)
   {
       if(reply)
       {

           RefundEntity.removeRefund(user, transaction);
           System.out.println(" Balance before="+user.getWallet().getBalance());

           user.getWallet().addMoney((transaction.getTotalCost()));
           user.getWallet().getBalance();
           System.out.println( " Balance after="+user.getWallet().getBalance());
           user.getUserHistory().removeTransaction(transaction);
       }
       else
       {
           RefundEntity.removeRefund(user, transaction);

           text = " Sorry Request is Rejected";

       }

   }
}
