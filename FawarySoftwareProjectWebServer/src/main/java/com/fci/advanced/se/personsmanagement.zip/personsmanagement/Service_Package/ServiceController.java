package com.fci.advanced.se.personsmanagement.Service_Package;
import com.fci.advanced.se.personsmanagement.ProviderEntity.*;
import com.fci.advanced.se.personsmanagement.ProviderEntity.Mobile.VodafoneMobileProviderEntity;
import com.fci.advanced.se.personsmanagement.RefundOperation.Transaction;
import com.fci.advanced.se.personsmanagement.model.CurrentUser;
import com.fci.advanced.se.personsmanagement.model.Response;
import com.fci.advanced.se.personsmanagement.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Provider;
import java.util.List;
import java.util.Objects;

import static com.fci.advanced.se.personsmanagement.Service_Package.ServiceType.*;

@RestController
@RequestMapping("/ServiceController")
public class ServiceController {
    private Service service;
    public static float totalCost;
    public ServiceController(){};
    public float callService(ServiceType serviceType, IProvider provider)
    {
        AllService allService = new AllService();
        allService.setupService();
         service = ServiceEntity.searchForService(serviceType) ;
        totalCost = service.request(provider);
        return totalCost;
    }
    @RequestMapping("/MobileRecharge")

    public Response<Transaction> callMobileRechargeService(@RequestParam List<String> providers)
    {
        ProviderFactory providerMobileCreator = new ProviderMobileCreator();
        IProvider provider =  providerMobileCreator.createProvider(providers);
        return getTransactionResponse(provider, MobileRecharge);
    }
    @RequestMapping("/Internet")

    public Response<Transaction> callInternetService(@RequestParam List<String> providers)
    {
        ProviderFactory ProviderInternetCreator = new ProviderInternetCreator();
        IProvider provider =  ProviderInternetCreator.createProvider(providers);
        return getTransactionResponse(provider, InternetPayment);
    }
    @RequestMapping("/LandLine")

    public Response<Transaction> callLandLineService(@RequestParam List<String> providers)
    {
        ProviderFactory providerLandLineCreator = new ProviderLandLineCreator();
        IProvider provider =  providerLandLineCreator.createProvider(providers);
        return getTransactionResponse(provider, Landline);
    }
    @RequestMapping("/Donation")

    public Response<Transaction> callDonationService(@RequestParam List<String> providers)
    {
        ProviderFactory  donationCreator= new ProviderDonationCreator();
        IProvider provider =  donationCreator.createProvider(providers);
        return getTransactionResponse(provider, Donation);
    }
    private Response<Transaction> getTransactionResponse(IProvider provider, ServiceType serviceType) {
        totalCost = callService(serviceType, provider);
        Response<Transaction> response = new Response<Transaction>();
        Transaction transaction = new Transaction(service, totalCost);
        response.setStatus(true);
        response.setMessage("Total cost Calculated");
        response.object =  transaction;
        return response;
    }
}
