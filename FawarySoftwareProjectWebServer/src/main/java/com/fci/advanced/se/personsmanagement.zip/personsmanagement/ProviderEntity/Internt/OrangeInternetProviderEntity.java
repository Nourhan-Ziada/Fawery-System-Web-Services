package com.fci.advanced.se.personsmanagement.ProviderEntity.Internt;

public class OrangeInternetProviderEntity extends InternetProviderEntity{
    @Override
    public float retrieveAmount() {
        return internetAmount;
    }
}
